import pandas as pd

df = pd.read_csv("bank_loan_applications.csv")
df.columns = df.columns.str.strip()

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)

print("=== Complete Dataset ===")
print(df)

print("\n=== Dataset Shape ===")
print(df.shape)

print("\n=== Column Names ===")
print(df.columns)

print("\n=== Data Types ===")
print(df.dtypes)

print("\n=== Info ===")
print(df.info())

print("\n=== Missing Values Before Handling ===")
print(df.isnull().sum())

df['Income'] = df['Income'].fillna(df['Income'].median())
df['CreditScore'] = df['CreditScore'].fillna(df['CreditScore'].mean())
df = df.dropna(subset=['LoanAmount'])

print("\n=== Missing Values After Handling ===")
print(df.isnull().sum())

duplicates_before = df.duplicated(subset=['ApplicationID']).sum()
df = df.drop_duplicates(subset=['ApplicationID'])
duplicates_after = df.duplicated(subset=['ApplicationID']).sum()
print(f"\nDuplicates before: {duplicates_before}, after removal: {duplicates_after}")

df['LoanStatus'] = df['LoanStatus'].str.capitalize()
df['LoanStatus'] = df['LoanStatus'].apply(lambda x: 'Approved' if x == 'Approved' else 'Rejected')
print("\n=== Unique LoanStatus Values ===")
print(df['LoanStatus'].unique())

def detect_outliers(data, column):
    Q1 = data[column].quantile(0.25)
    Q3 = data[column].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    outliers = data[(data[column] < lower) | (data[column] > upper)]
    return outliers

income_outliers = detect_outliers(df, 'Income')
loan_outliers = detect_outliers(df, 'LoanAmount')

print("\n=== Income Outliers ===")
print(income_outliers)

print("\n=== LoanAmount Outliers ===")
print(loan_outliers)

high_risk_loans = df[df['LoanAmount'] > 2 * df['Income']]
print("\n=== High-Risk Loans (LoanAmount > 2x Income) ===")
print(high_risk_loans)

avg_loan_by_employment = df.groupby('EmploymentStatus')['LoanAmount'].mean().reset_index()
print("\n=== Average LoanAmount by EmploymentStatus ===")
print(avg_loan_by_employment)

df.to_csv("cleaned_loan_data.csv", index=False)
print("\nCleaned dataset exported to 'cleaned_loan_data.csv'")