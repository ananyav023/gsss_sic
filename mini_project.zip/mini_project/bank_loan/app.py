import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import plotly.express as px


# Streamlit Page Config

st.set_page_config(page_title="Bank Loan Data Cleaning & Analysis", layout="wide")

st.title("Bank Loan Application Data Preprocessing & Analysis")
st.markdown("This app cleans, preprocesses, analyzes, and visualizes loan application data.")


# Step 1: Load Dataset

st.sidebar.header("Upload Dataset")
uploaded_file = st.sidebar.file_uploader("Upload CSV file", type=["csv"])

if uploaded_file:
    df = pd.read_csv(uploaded_file)

    # Fix column names
    df.columns = df.columns.str.strip()

    
    # Step 2: Handle Missing Values
    
    df['Income'] = df['Income'].fillna(df['Income'].median())
    df['CreditScore'] = df['CreditScore'].fillna(df['CreditScore'].mean())
    df = df.dropna(subset=['LoanAmount'])


    # Step 3: Remove Duplicates

    df = df.drop_duplicates(subset=['ApplicationID'])

    # Step 4: Standardize Categorical Values

    df['LoanStatus'] = df['LoanStatus'].str.capitalize()
    df['LoanStatus'] = df['LoanStatus'].apply(lambda x: 'Approved' if x == 'Approved' else 'Rejected')

  
    # Step 5: Detect Outliers
  
    def detect_outliers(data, column):
        Q1 = data[column].quantile(0.25)
        Q3 = data[column].quantile(0.75)
        IQR = Q3 - Q1
        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR
        outliers = data[(data[column] < lower) | (data[column] > upper)]
        return outliers

    
    # Step 6: High-Risk Loans
 
    high_risk_loans = df[df['LoanAmount'] > 2 * df['Income']]

    # Step 7: Group & Aggregate
   
    avg_loan_by_employment = df.groupby('EmploymentStatus')['LoanAmount'].mean().reset_index()

    
    # Frontend Features
   
    st.subheader("View Dataset")
    search_term = st.text_input("Search by Applicant Name or ID:")
    if search_term:
        filtered_df = df[df.apply(lambda row: row.astype(str).str.contains(search_term, case=False).any(), axis=1)]
        st.dataframe(filtered_df, use_container_width=True)
    else:
        st.dataframe(df, use_container_width=True)

    # Dataset Summary
    st.subheader("Dataset Summary")
    st.write(df.describe())

    # Missing Values
    st.subheader("Missing Values After Cleaning")
    st.write(df.isnull().sum())

    # Loan Amount Distribution
    st.subheader("Loan Amount Distribution")
    fig = px.histogram(df, x="LoanAmount", color="LoanStatus", nbins=20, title="Loan Amount Distribution")
    st.plotly_chart(fig, use_container_width=True)

    # Employment vs Loan
    st.subheader("Average Loan by Employment Status")
    fig = px.bar(avg_loan_by_employment, x="EmploymentStatus", y="LoanAmount",
                 title="Average Loan by Employment Status", color="EmploymentStatus")
    st.plotly_chart(fig, use_container_width=True)

    # Outlier Explorer
    st.subheader("Outlier Detection")
    option = st.selectbox("Choose column to detect outliers:", ["Income", "LoanAmount"])
    outliers = detect_outliers(df, option)
    st.write(outliers)

    # High-Risk Loans
    st.subheader("High-Risk Loans (LoanAmount > 2x Income)")
    st.write(high_risk_loans)

    # Download Cleaned Dataset
    st.subheader("Download Cleaned Dataset")
    st.download_button(
        label="Download CSV",
        data=df.to_csv(index=False).encode("utf-8"),
        file_name="cleaned_loan_data.csv",
        mime="text/csv"
    )

else:
    st.info("Please upload a CSV file to begin.")